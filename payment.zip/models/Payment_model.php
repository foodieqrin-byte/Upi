<?php
class Payment_model extends CI_Model {

    public function create_upi_id_request($data) {
        // Integrate with actual UPI gateway API here (for demo, just return success)
        return [
            'success' => true,
            'message' => 'Request sent to UPI ID',
            'txn_id' => 'TXN' . rand(100000,999999)
        ];
    }

    public function generate_upi_qr($data) {
        $upi_uri = sprintf(
            'upi://pay?pa=%s@upi&pn=%s&am=%s&cu=INR',
            'merchantid', // Change 'merchantid' to your UPI ID
            urlencode($data['payee_name']),
            $data['amount']
        );
        return $upi_uri;
    }

    public function handle_callback($data) {
        // Validate and update transaction status
        return true;
    }

    public function check_status($txn_id) {
        return [
            'txn_id' => $txn_id,
            'status' => 'SUCCESS'
        ];
    }
}