<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payment extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Payment_model');
    }

    public function index() {
        $this->load->view('payment/choose_method');
    }

    public function upi_id() {
        if ($this->input->method() === 'post') {
            $data = [
                'upi_id' => $this->input->post('upi_id'),
                'amount' => $this->input->post('amount'),
            ];
            $response = $this->Payment_model->create_upi_id_request($data);
            $this->load->view('payment/upi_id_status', ['response' => $response]);
        } else {
            $this->load->view('payment/upi_id_form');
        }
    }

    public function qr_code() {
        if ($this->input->method() === 'post') {
            $data = [
                'amount' => $this->input->post('amount'),
                'payee_name' => $this->input->post('payee_name'),
            ];
            $qr = $this->Payment_model->generate_upi_qr($data);
            $this->load->view('payment/qr_code', ['qr' => $qr, 'data' => $data]);
        } else {
            $this->load->view('payment/qr_code_form');
        }
    }

    public function callback() {
        $data = $this->input->post();
        $result = $this->Payment_model->handle_callback($data);
        echo $result ? "OK" : "FAILED";
    }

    public function status($txn_id) {
        $status = $this->Payment_model->check_status($txn_id);
        $this->load->view('payment/status', ['status' => $status]);
    }
}