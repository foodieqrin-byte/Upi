# UPI Payment Plugin for CodeIgniter

## Features
- UPI ID payment support
- UPI QR code payment support
- Transaction status checking

## Installation
1. Copy `Payment.php` to `application/controllers/`
2. Copy `Payment_model.php` to `application/models/`
3. Copy everything from `views/payment/` to `application/views/payment/`
4. Add the routes from `routes.php` to your `application/config/routes.php`
5. Change `'merchantid'` in `Payment_model.php` to your own UPI ID.

## Usage
- Access `/payment` in your browser for payment options.
- For real UPI transactions, you must integrate an actual UPI payment provider in `Payment_model.php`.

## Note
- This is a demo plugin. For production, ask your developer to connect to a UPI gateway.