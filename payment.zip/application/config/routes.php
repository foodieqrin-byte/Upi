$route['payment'] = 'payment/index';
$route['payment/upi_id'] = 'payment/upi_id';
$route['payment/qr_code'] = 'payment/qr_code';
$route['payment/callback'] = 'payment/callback';
$route['payment/status/(:any)'] = 'payment/status/$1';