<!DOCTYPE html>
<html>
<head>
    <title>Scan UPI QR Code</title>
</head>
<body>
    <h2>Scan UPI QR Code to Pay</h2>
    <p>Amount: <?= $data['amount'] ?></p>
    <p>Payee: <?= $data['payee_name'] ?></p>
    <img src="https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl=<?= urlencode($qr) ?>" alt="UPI QR Code">
    <p>Or use UPI URI: <code><?= $qr ?></code></p>
</body>
</html>