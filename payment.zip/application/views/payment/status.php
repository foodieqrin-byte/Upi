<!DOCTYPE html>
<html>
<head>
    <title>Payment Status</title>
</head>
<body>
    <h2>Transaction Status</h2>
    <p>Transaction ID: <?= $status['txn_id'] ?></p>
    <p>Status: <?= $status['status'] ?></p>
</body>
</html>