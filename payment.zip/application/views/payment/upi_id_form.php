<!DOCTYPE html>
<html>
<head>
    <title>Pay via UPI ID</title>
</head>
<body>
    <h2>Enter Payment Details (UPI ID)</h2>
    <form method="post">
        <label>UPI ID:</label>
        <input type="text" name="upi_id" required><br>
        <label>Amount:</label>
        <input type="number" name="amount" required><br>
        <button type="submit">Pay</button>
    </form>
</body>
</html>