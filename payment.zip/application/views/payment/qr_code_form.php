<!DOCTYPE html>
<html>
<head>
    <title>Pay via QR Code</title>
</head>
<body>
    <h2>Enter Payment Details (QR Code)</h2>
    <form method="post">
        <label>Payee Name:</label>
        <input type="text" name="payee_name" required><br>
        <label>Amount:</label>
        <input type="number" name="amount" required><br>
        <button type="submit">Generate QR</button>
    </form>
</body>
</html>