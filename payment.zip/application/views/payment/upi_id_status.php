<!DOCTYPE html>
<html>
<head>
    <title>UPI ID Payment Status</title>
</head>
<body>
    <h2>Payment Status</h2>
    <p><?= $response['message'] ?></p>
    <p>Transaction ID: <?= $response['txn_id'] ?></p>
    <a href="<?= site_url('payment/status/'.$response['txn_id']) ?>">Check Status</a>
</body>
</html>