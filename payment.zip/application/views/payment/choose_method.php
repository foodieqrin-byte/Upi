<!DOCTYPE html>
<html>
<head>
    <title>Choose Payment Method</title>
</head>
<body>
    <h2>Choose Payment Method</h2>
    <a href="<?= site_url('payment/upi_id') ?>">Pay via UPI ID</a><br>
    <a href="<?= site_url('payment/qr_code') ?>">Pay via QR Code</a>
</body>
</html>